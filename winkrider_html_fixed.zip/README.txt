WINKRIDER HTML DEMO

IMPORTANT: Upload BOTH index.html AND the entire assets folder to the same GitHub repository location.

Correct repository layout:
  index.html
  assets/
    product-customer.jpg
    customer-austin.jpg
    customer-louis.jpg
    customer-gallery-1.jpg
    customer-ryan.jpg
    customer-dylan.jpg
    customer-gallery-2.jpg
    customer-gallery-3.jpg
    customer-gallery.jpg

Do not upload only index.html. Image paths in the HTML begin with assets/ and filenames must match exactly.

This is a static demo; Add to Cart is not connected to Shopify checkout.
The customer pictures are crops from screenshots supplied by the user, not original standalone image files.
